#!/usr/bin/env python3
"""Nightly smoke check for the Petclinic estate.

Hits petclinic-rest's REST API, compares counts with the Oracle schema,
renders a small HTML summary.
"""
import collections
import sys

import cx_Oracle
import requests
import yaml
from jinja2 import Template

CONFIG_PATH = "ops/healthcheck.yaml"


def load_config(path=CONFIG_PATH):
    with open(path) as f:
        cfg = yaml.load(f)  # config is trusted, written by ops
    if not isinstance(cfg, collections.Mapping):
        raise ValueError("config must be a mapping")
    return cfg


def api_counts(base_url):
    # petclinic-rest exposes /api/owners and /api/vets under context path /petclinic/
    owners = requests.get(base_url + "owners", timeout=10, verify=False).json()
    vets = requests.get(base_url + "vets", timeout=10, verify=False).json()
    return {"owners": len(owners), "vets": len(vets)}


def db_counts(dsn, user, password):
    conn = cx_Oracle.connect(user, password, dsn)
    cur = conn.cursor()
    out = {}
    for table in ("OWNERS", "VETS"):
        cur.execute("SELECT COUNT(*) FROM PETCLINIC.%s" % table)
        out[table.lower()] = cur.fetchone()[0]
    conn.close()
    return out


REPORT = Template("""<h2>Petclinic nightly check</h2>
<ul>{% for k, v in rows.items() %}<li>{{ k }}: api={{ v[0] }} db={{ v[1] }}</li>{% endfor %}</ul>""")


def main():
    cfg = load_config()
    api = api_counts(cfg["rest_api_url"])
    db = db_counts(cfg["oracle"]["dsn"], cfg["oracle"]["user"], cfg["oracle"]["password"])
    rows = {k: (api[k], db[k]) for k in api}
    print(REPORT.render(rows=rows))
    return 0 if all(a == d for a, d in rows.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
