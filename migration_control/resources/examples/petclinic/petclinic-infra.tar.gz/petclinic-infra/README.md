# petclinic-infra

Ops glue for the Petclinic estate. Owned by the platform team.

| Piece | What it does | Talks to |
|---|---|---|
| `ops/healthcheck.py` | Nightly smoke check: hits the REST API, checks owner/vet counts against Oracle, emails a summary | `petclinic-rest` (`http://<host>:9966/petclinic/api/`), Oracle `PETCLINIC` schema |
| `oracle/db-inventory.yaml` | Declared production database version and patch level | — |
| `oracle/schema.sql` | Oracle DDL for the Petclinic schema (prod runs on Oracle, not HSQLDB) | used by `petclinic-rest` via the `oracle` Maven profile |
| `maven/oracle-profile.xml` | Maven profile merged into `petclinic-rest/pom.xml` at build time to add the Oracle JDBC driver | `petclinic-rest` |

Runtime: the backend WAR runs on the JDK declared in `oracle/db-inventory.yaml → app_servers`. The Angular front (`petclinic-angular`) is built with its own toolchain and served statically; its `REST_API_URL` points at the backend above.
