-- Petclinic schema for Oracle (prod). Mirrors petclinic-rest's HSQLDB schema.
CREATE SEQUENCE owners_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE vets_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE pets_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE visits_seq START WITH 1 INCREMENT BY 1;

CREATE TABLE vets (
  id         NUMBER(10) PRIMARY KEY,
  first_name VARCHAR2(30),
  last_name  VARCHAR2(30)
);
CREATE TABLE specialties (id NUMBER(10) PRIMARY KEY, name VARCHAR2(80));
CREATE TABLE vet_specialties (
  vet_id       NUMBER(10) REFERENCES vets(id),
  specialty_id NUMBER(10) REFERENCES specialties(id)
);
CREATE TABLE types (id NUMBER(10) PRIMARY KEY, name VARCHAR2(80));
CREATE TABLE owners (
  id         NUMBER(10) PRIMARY KEY,
  first_name VARCHAR2(30),
  last_name  VARCHAR2(30),
  address    VARCHAR2(255),
  city       VARCHAR2(80),
  telephone  VARCHAR2(20)
);
CREATE TABLE pets (
  id         NUMBER(10) PRIMARY KEY,
  name       VARCHAR2(30),
  birth_date DATE,
  type_id    NUMBER(10) REFERENCES types(id),
  owner_id   NUMBER(10) REFERENCES owners(id)
);
CREATE TABLE visits (
  id          NUMBER(10) PRIMARY KEY,
  pet_id      NUMBER(10) REFERENCES pets(id),
  visit_date  DATE,
  description VARCHAR2(255)
);
